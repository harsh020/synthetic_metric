import numpy as np

class Dtypes:
    CATEGORICAL = ['object', 'category']
    NUMERIC = [np.number]
